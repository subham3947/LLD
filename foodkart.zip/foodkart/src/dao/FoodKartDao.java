package dao;

import java.util.List;
import java.util.Map;

import entity.Restaurant;
import entity.User;

public class FoodKartDao {

    static FoodKartDao foodKartDaoInstance;
    
    User loggedInUser;
    Map<String, User> registeredUser;
    Map<String, Restaurant> registeredRestaurant;


    public static FoodKartDao getInstance(){
        if(foodKartDaoInstance == null)
            foodKartDaoInstance =  new FoodKartDao();
        return foodKartDaoInstance;
    }


    public void insertNewUser(User user) {

        if(user != null)
            registeredUser.put(user.getName(), user);
    }


    public void userLogin(User user) {
        if(user != null)
            loggedInUser = user;
    }

    public void logoutUser() {
        loggedInUser = null;
    }


    public void registerRestaurant(Restaurant restaurant) {
    }


    public List<Restaurant> getAllRegisteredRestaurants() {
        return null;
    }


    public Restaurant getRestaurant(String name) {
        return null;
    }


    public void updateRestaurant(Restaurant restaurant, String name) {
    }
    
}
