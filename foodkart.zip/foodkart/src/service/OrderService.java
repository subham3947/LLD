package service;

public interface OrderService {
    

    public void placeOrder(String restaurantName, int quantity);
}
