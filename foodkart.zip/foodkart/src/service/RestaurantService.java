package service;

import java.util.List;

import entity.Restaurant;
import entity.Review;

public interface RestaurantService {
    

    public void registerRestaurant(Restaurant restaurant);

    public List<Restaurant> getAllRestaurantsSortedByCriteria(String criteria);

    public void updateQuantity(String name, int quantity);

    public void updateRestaurantLocation(String name, String location);

    public void updateRestaurantRating(String restaurantName, Review review);
    
}
