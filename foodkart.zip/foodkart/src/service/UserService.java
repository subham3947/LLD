package service;

import entity.User;

public interface UserService {

    public void registerUser(User user);

    public void loginUser(User user);

    public void logoutUser();

    public void createReview(String restaurant, int rating, String comment);

    
}
