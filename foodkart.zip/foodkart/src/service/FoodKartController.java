package service;

public class FoodKartController {

    
    UserService userService;
    RestaurantService restaurantService;
    OrderService orderService;

    public FoodKartController() {
        userService = new UserServiceImpl();
        restaurantService = new RestaurantServiceImpl();
        orderService = new OrderServiceImpl();
    }

    public void registerUser(String name, String gender, String phone, String location) {
    }

    public void registerRestaurant(String name, String location, String item, int itemPrice, int itemQuantity) {
    }

    public void loginUser(String phone) {
    }

    public void showRestaurants(String criteria) {
    }

    public void placeOrder(String restaurantName, int itemQuantity) {
    }

    public void updateLocation(String restaurantName, String newLocation) {
    }

    public void createReview(String restaurantName, int rating, String comments) {
    }
}
