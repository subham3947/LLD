package service;

import dao.FoodKartDao;

public class OrderServiceImpl implements OrderService {


    FoodKartDao foodKartDao;

    public OrderServiceImpl() {
        this.foodKartDao = FoodKartDao.getInstance();
    }
    

    @Override
    public void placeOrder(String restaurantName, int quantity) {
        // TODO Auto-generated method stub
        
    }
    
}
