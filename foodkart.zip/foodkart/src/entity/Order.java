package entity;

public class Order {

    Restaurant restaurant;
    int quantity;
    
}
