package entity;

import java.util.Comparator;
import java.util.List;
import java.util.Set;

public class Restaurant {

    Item item;
    Set<String> serviceableLocation;
    List<Review> reviews;

    public List<Review> getReviews() {
        return this.reviews;
    }

    public void setReviews(List<Review> reviews) {
        this.reviews = reviews;
    }
    double avgRating;

    public Set<String> getServiceableLocation() {
        return this.serviceableLocation;
    }

    public void setServiceableLocation(Set<String> location) {
        this.serviceableLocation = location;
    }

    public Item getItem() {
        return this.item;
    }

    public void setItem(Item item) {
        this.item = item;
    }

    

    public double getAvgRating() {
        return this.avgRating;
    }

    public void setAvgRating(double avgRating) {
        this.avgRating = avgRating;
    }

}

