package com.example.geektrust.controller;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class PortfolioManagerImplTest {

    @Test
    void processOrderAllocate() {
    }

    @Test
    void processOrderSip() {
    }

    @Test
    void processOrderChange() {
    }

    @Test
    void processOrderBalance() {
    }

    @Test
    void processOrderRebalance() {
    }
}