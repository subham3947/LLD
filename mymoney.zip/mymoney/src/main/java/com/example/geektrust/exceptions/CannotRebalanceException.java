package com.example.geektrust.exceptions;

public class CannotRebalanceException extends Exception{

    public CannotRebalanceException(){
        super("CANNOT_REBALANCE");
    }
}
