package com.example.geektrust;

import com.example.geektrust.controller.PortfolioManager;
import com.example.geektrust.controller.PortfolioManagerImpl;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) throws FileNotFoundException {

        PortfolioManager portfolioManager = new PortfolioManagerImpl();
        String input = "";
        String filename = args[0];
        //String filename = "G:\\LLD\\input.txt";
        Scanner sc = new Scanner(new File(filename));
        //Scanner sc = new Scanner(file);
        while (sc.hasNextLine()) {
            input = sc.nextLine();
            //System.out.println(input);
            portfolioManager.processOrder(input);
        }
        sc.close();

    }
}
