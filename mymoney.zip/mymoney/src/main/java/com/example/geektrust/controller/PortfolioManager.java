package com.example.geektrust.controller;

public interface PortfolioManager {

     void processOrder(String orderString) ;
}
