package com.example.geektrust.constants;

public enum Operations {
    ALLOCATE,
    SIP,
    CHANGE,
    BALANCE,
    REBALANCE
}
